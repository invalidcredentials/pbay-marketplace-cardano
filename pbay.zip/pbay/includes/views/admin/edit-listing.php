<?php if (!defined('ABSPATH')) exit;
// Edit listing reuses create-listing.php with pre-populated data
// Redirected from inventory page via ?edit=ID
include __DIR__ . '/create-listing.php';
