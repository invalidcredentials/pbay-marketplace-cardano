# Changelog

All notable changes to PBay are documented here.

---

## [0.1.1-alpha] - 2026-02-10

### Added
- **Terms of Service agreement gate** — Admins must read and accept the ToS before accessing any PBay page. The ToS card appears at the top of the How It Works page until accepted, then moves below the Requirements section. All other PBay admin pages redirect to How It Works until the terms are agreed to.
- How It Works page (Quick Guide + Full Documentation tabs) now included in repository.

---

## [0.1.0-alpha] - 2026-02-10

Initial public release.
